<?php namespace Talentos\Commands;

abstract class Command {

	//

}
