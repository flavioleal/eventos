<?php namespace Talentos\Events;

abstract class Event {

	//

}
