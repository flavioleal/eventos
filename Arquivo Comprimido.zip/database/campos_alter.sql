use eventos;

select * from campo_tipos;

ALTER TABLE campos ADD mascara VARCHAR(100);